//This is the base javascript filefunction billme()

function billme()
{
        var v1= document.order.porkQty.value;
    
        //These lines define the variables.
        
            v1= parseInt(v1);
      
      
            order.subtotalBox.value= ((5.8*24) + v1*52)/(13*Math.sin(5))
       }
        
        function porkImage() {
            document.getElementById("mainpic").src="images/Therapy.png"
        }
        
     